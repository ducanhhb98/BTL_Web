<?php 

require_once("config.php");

if(isset($_POST['login'])){

    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);

    $sql = "SELECT * FROM users WHERE username=:username OR email=:email";
    $stmt = $db->prepare($sql);
    
    // bind parameter ke query
    $params = array(
        ":username" => $username,
        ":email" => $username
    );

    $stmt->execute($params);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // jika user terdaftar
    if($user){
        // verifikasi password
        if(password_verify($password, $user["password"])){
            // buat Session
            session_start();
            $_SESSION["user"] = $user;
            // login sukses, alihkan ke halaman timeline
            header("Location: ../dangnhapsong.php");
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Đăng nhập</title>

    <link rel="stylesheet" href="css/bootstrap.min.css" />
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="row">
        <div class="col-md-6">

        <p>&larr; <a href="../dichvusanbay.php">quay về trang chủ</a>

        <h4>Đăng nhập ngay</h4>
        <p>Bạn chưa có tài khoản? <a href="register.php">Mời bạn đăng ký</a></p>

        <form action="" method="POST">

            <div class="form-group">
                <label for="username">Tên đăng nhập</label>
                <input class="form-control" type="text" name="username" placeholder="Tên đăng nhập hoặc email" />
            </div>


            <div class="form-group">
                <label for="password">Mật khẩu</label>
                <input class="form-control" type="password" name="password" placeholder="Mật khẩu" />
            </div>

            <input type="submit" class="btn btn-success btn-block" name="login" value="Đăng nhập" />

        </form>
            
        </div>

        <div class="col-md-6">
            <!-- isi dengan sesuatu di sini -->
        </div>

    </div>
</div>
    
</body>
</html>